'use strict';

/* Controllers */
app.controller('SafetyController', ['$scope', '$http', '$state', function ($scope, $http, $state) {
    // 初始化
    $scope.init = function (params) {

    }

    $scope.init();
}]);