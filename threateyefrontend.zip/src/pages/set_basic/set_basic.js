/* Controllers */
app.controller('Set_basicController', ['$scope', '$http', '$state', function ($scope, $http, $state) {
    // 初始化
    $scope.init = function (params) {

    }

    $scope.init();
}]);